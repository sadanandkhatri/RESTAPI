using FDB.WebAPI.Common;
using FDB.WebAPI.Controllers;
using FDB.WebAPI.DAL;
using FDB.WebAPI.Interface;
using FDB.WebAPI.Model;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace FDB.WebAPI.Tests
{
    public class FDBTests
    {

        [Fact]
        public void ContactAddTest()
        {
            var contanct = new Mock<IContactsRepository>();
            contanct.Setup(x => x.AddContact(It.IsAny<Contact>())).Returns(true);
            var contactController = new ContactController(contanct.Object);
            var result = contactController.Add(new Contact() { Id = 1, Email = "abc@gmail.com", FirstName = "test first name", LastName = "last name", PhoneNumber = "3123213", Status = "Active" });
            Assert.Equal(Constants.CONTACT_ADDED_SUCCESSFULLY, result);
        }

        [Fact]
        public void ContactUpdateTest()
        {
            var contanct = new Mock<IContactsRepository>();
            contanct.Setup(x => x.UpdateContact(It.IsAny<Contact>())).Returns(true);
            var contactController = new ContactController(contanct.Object);
            var result = contactController.Update(new Contact() { Id = 1, Email = "pqr@gmail.com", FirstName = "test first name", LastName = "last name", PhoneNumber = "3123213", Status = "Active" });
            Assert.Equal(Constants.CONTACT_UPDATE_SUCCESSFULLY,result);
        }

        [Fact]
        public void ContactGetTest()
        {
            var contanct = new Mock<IContactsRepository>();
            List<Contact> lstContact = GetContactList();
            contanct.Setup(x => x.GetContancts()).Returns(lstContact);
            var contactController = new ContactController(contanct.Object);
            var result = contactController.Get();
            Assert.NotNull(result);
        }

        [Fact]
        public void ContactDeleteTest()
        {
            var contanct = new Mock<IContactsRepository>();
            List<Contact> lstContact = GetContactList();
            contanct.Setup(x => x.DeleteContact(2)).Returns(true);
            var contactController = new ContactController(contanct.Object);
            var result = contactController.Delete(lstContact[1]);
            Assert.Equal(Constants.CONTACT_DELETE_SUCCESSFULLY,result);
        }



        private static List<Contact> GetContactList()
        {
            List<Contact> lstContact = new List<Contact>();
            for (int i = 0; i < 5; i++)
            {
                lstContact.Add(new Contact()
                {
                    Id = i + 1,
                    Email = "abc" + i + "@gmail.com",
                    FirstName = "DummyFirst" + i.ToString(),
                    LastName = "DummyLast" + i.ToString(),
                    PhoneNumber = "123123213" + i,
                    Status = "Active"
                }
                );
            }

            return lstContact;
        }
    }
}
