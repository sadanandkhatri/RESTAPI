﻿using FDB.WebAPI.Model;
using System.Collections.Generic;

namespace FDB.WebAPI.Interface
{
    //IContacts
    public interface IContactsRepository
    {
        public IEnumerable<Contact> GetContancts();
        public bool AddContact(Contact contactModel);
        public bool UpdateContact(Contact contactModel);
        public bool DeleteContact(int id);
    }

}
