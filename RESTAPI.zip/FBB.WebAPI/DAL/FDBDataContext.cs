﻿using FDB.WebAPI.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FDB.WebAPI.DAL
{
    public class FDBDataContext : DbContext
    {
        public FDBDataContext(DbContextOptions<FDBDataContext> options) : base(options) { }
        public DbSet<Contact> Contact { get; set; }
    }
}

