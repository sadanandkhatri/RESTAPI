﻿namespace FDB.WebAPI.Helpers
{
    public class Helper
    {
        public static string GenerateMessage(bool result, string errorMessage, string successMessage)
        {
            if (result) return successMessage; else return errorMessage;
        }
    }
}
