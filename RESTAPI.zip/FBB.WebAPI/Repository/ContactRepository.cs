﻿using FDB.WebAPI.DAL;
using FDB.WebAPI.Interface;
using FDB.WebAPI.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace FDB.WebAPI.Repository
{
    public class ContactRepository : IContactsRepository
    {
        readonly FDBDataContext fDBDataContext;
        public ContactRepository(FDBDataContext fDBDataContext)
        {
            this.fDBDataContext = fDBDataContext;
        }
        public bool AddContact(Contact contactModel)
        {
            bool result;
            try
            {
                fDBDataContext.Contact.Add(contactModel);
                fDBDataContext.SaveChanges();
                result = true;
            }
            catch (Exception ex)
            {
                result = false;
                // Log Error in log file/App insights 
            }
            return result;
        }

        public bool DeleteContact(int id)
        {
            bool result;
            try
            {
                var contactToDelete = fDBDataContext.Contact.Find(id);
                fDBDataContext.Contact.Remove(contactToDelete);
                fDBDataContext.SaveChanges();
                result = true;
            }
            catch (Exception ex)
            {
                result = false;
                // Log Error in log file/App insights 
            }
            return result;
        }

        public IEnumerable<Contact> GetContancts()
        {
            return fDBDataContext.Contact.ToArray();
        }

        public bool UpdateContact(Contact contactModel)
        {
            bool result;
            try
            {
                var contactToUpdate = fDBDataContext.Contact.Find(contactModel.Id);
                contactToUpdate.FirstName = contactModel.FirstName;
                contactToUpdate.LastName = contactModel.LastName;
                contactToUpdate.Email = contactModel.Email;
                contactToUpdate.PhoneNumber = contactModel.PhoneNumber;
                contactToUpdate.Status = contactModel.Status;
                fDBDataContext.SaveChanges();
                result = true;
            }
            catch (Exception ex)
            {
                result = false;
                // Log Error in log file/App insights 
            }
            return result;
        }
    }
}
