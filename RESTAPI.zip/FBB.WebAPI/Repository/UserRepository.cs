﻿using FDB.WebAPI.Helpers;
using FDB.WebAPI.Interface;
using FDB.WebAPI.Model;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FDB.WebAPI.Repository
{
    public class UserRepository : IUserRepository
    {
        private List<User> user = new List<User>
        {
            new User { Id = 1, FirstName = "Test", LastName = "User", Username = "test", Password = "test" }
        };

        public async Task<User> Authenticate(string username, string password)
        {
            var user = await Task.Run(() => this.user.SingleOrDefault(x => x.Username == username && x.Password == password));

            // return null if user not found
            if (user == null)
                return null;

            // authentication successful so return user details without password
            return user.WithoutPassword();
        }
        
        public async Task<IEnumerable<User>> GetAll()
        {
            return await Task.Run(() => user.WithoutPasswords());
        }
    }
}
