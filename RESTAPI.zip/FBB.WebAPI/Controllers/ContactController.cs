﻿using FDB.WebAPI.Common;
using FDB.WebAPI.Interface;
using FDB.WebAPI.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using FDB.WebAPI.Helpers;

namespace FDB.WebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Authorize]
    public class ContactController : ControllerBase
    {
        public IContactsRepository contactRepository { get; set; }

        public ContactController(IContactsRepository contactRepository)
        {
            this.contactRepository = contactRepository;
        }

        [HttpGet]
        public IEnumerable<Contact> Get()
        {
            return this.contactRepository.GetContancts();
        }

        [HttpPut]
        public string Update(Contact contact)
        {
            return Helper.GenerateMessage(this.contactRepository.UpdateContact(contact),
                Constants.UNABLE_TO_UPDATE_CONTACT, Constants.CONTACT_UPDATE_SUCCESSFULLY);
        }

       

        [HttpPost]
        public string Add(Contact contact)
        {
            return Helper.GenerateMessage(this.contactRepository.AddContact(contact),
                Constants.UNABLE_TO_ADD_CONTACT, Constants.CONTACT_ADDED_SUCCESSFULLY);
        }

        [HttpDelete]
        public string Delete(Contact contact)
        {
            return Helper.GenerateMessage(this.contactRepository.DeleteContact(contact.Id),
                Constants.UNABLE_TO_DELETE_CONTACT, Constants.CONTACT_DELETE_SUCCESSFULLY);
        }
    }
}
