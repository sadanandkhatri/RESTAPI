﻿namespace FDB.WebAPI.Common
{
    /// <summary>
    /// Constants
    /// </summary>
    public class Constants
    {
        public const string UNABLE_TO_UPDATE_CONTACT = "Unable to update contact";
        public const string CONTACT_UPDATE_SUCCESSFULLY = "Contact updated successfully.";

        public const string UNABLE_TO_ADD_CONTACT = "Unable to add contact";
        public const string CONTACT_ADDED_SUCCESSFULLY = "Contact added successfully.";

        public const string UNABLE_TO_DELETE_CONTACT = "Unable to delete contact";
        public const string CONTACT_DELETE_SUCCESSFULLY = "Contact delete successfully.";
    }
}
